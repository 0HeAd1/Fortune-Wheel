const button = (document.getElementsByClassName('button'))[0];
button.addEventListener('click', () => {alert('You are lox')});